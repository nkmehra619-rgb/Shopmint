# MintChat Android APK project

This is a native Android wrapper around the MintChat real-time web app.

## What it contains
- Pink MintChat UI
- Supabase login/register
- Real-time 1-to-1 chat
- Image/video upload UI
- Android file picker
- Android notification permission request
- Portrait mobile layout

## IMPORTANT: connect Supabase
Edit:
`app/src/main/assets/app.js`

Replace:
`YOUR_SUPABASE_URL`
and
`YOUR_SUPABASE_PUBLISHABLE_KEY`

with your Supabase project values.

The SQL database/storage setup is in the previous `MintChat_Real_Supabase` package's `schema.sql`.

## Build an APK
Install the latest Android Studio, open this folder, let Gradle sync, then:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

Or use:
`gradlew assembleDebug`

The debug APK will be under:
`app/build/outputs/apk/debug/app-debug.apk`

Android Studio/Gradle must have the Android SDK and build tools installed.

## Direct phone install
Copy `app-debug.apk` to your Android phone and open it from Files/Downloads. Android may ask you to allow installation from that source.

## Push notifications
The native permission is included, but actual background push delivery still needs Firebase Cloud Messaging (FCM) plus a server/Edge Function. The current Supabase chat code already handles realtime foreground messages.

## Security
Do not put a Supabase service-role key in the app. Use only the publishable/anon client key with Row Level Security enabled.
