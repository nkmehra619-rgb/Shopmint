const CONFIG={url:"YOUR_SUPABASE_URL",key:"YOUR_SUPABASE_PUBLISHABLE_KEY"};
const sb=supabase.createClient(CONFIG.url,CONFIG.key);
let me=null,activeUser=null,channel=null,pendingFile=null;

const $=id=>document.getElementById(id);
function configured(){return !CONFIG.url.startsWith("YOUR_")&&!CONFIG.key.startsWith("YOUR_")}
function msg(t){$("authMsg").textContent=t}
function initials(n){return (n||"?").split(" ").map(x=>x[0]).join("").slice(0,2).toUpperCase()}
async function boot(){
 if(!configured()){msg("Add your Supabase URL and publishable key in app.js first.");return}
 const {data}=await sb.auth.getSession(); if(data.session){await start(data.session.user)}
 sb.auth.onAuthStateChange(async(_e,s)=>{if(s) await start(s.user); else {me=null;$("app").classList.add("hidden");$("auth").classList.remove("hidden")}})
}
async function start(user){
 me=user;$("auth").classList.add("hidden");$("app").classList.remove("hidden");$("onlineLabel").textContent="Online";
 await loadUsers(); subscribePresence(); subscribeMessages();
}
async function signUp(){
 const email=$("authEmail").value.trim(),password=$("authPassword").value,name=$("authName").value.trim()||email.split("@")[0];
 if(password.length<6)return msg("Password must be at least 6 characters.");
 const {data,error}=await sb.auth.signUp({email,password,data:{full_name:name}});
 if(error)return msg(error.message); if(!data.session)msg("Account created. Check your email to confirm, then log in.");
}
async function login(){const {error}=await sb.auth.signInWithPassword({email:$("authEmail").value.trim(),password:$("authPassword").value});if(error)msg(error.message)}
async function loadUsers(q=""){
 let query=sb.from("profiles").select("id,full_name,avatar_url,last_seen").neq("id",me.id).order("full_name");
 if(q)query=query.ilike("full_name",`%${q}%`);
 const {data,error}=await query; if(error)return;
 $("userList").innerHTML=(data||[]).map(u=>`<div class="user-row" data-id="${u.id}"><div class="avatar">${initials(u.full_name)}</div><div class="row-main"><strong>${escapeHtml(u.full_name||"User")}</strong><small>${u.last_seen?"Last seen recently":"Available"}</small></div></div>`).join("")||"<p>No other users yet.</p>";
 document.querySelectorAll(".user-row").forEach(x=>x.onclick=()=>openChat(x.dataset.id));
}
function subscribePresence(){sb.from("profiles").update({last_seen:new Date().toISOString()}).eq("id",me.id)}
function subscribeMessages(){channel=sb.channel("messages-global").on("postgres_changes",{event:"INSERT",schema:"public",table:"messages"},p=>{if(activeUser && ((p.new.sender_id===activeUser.id&&p.new.receiver_id===me.id)||(p.new.sender_id===me.id&&p.new.receiver_id===activeUser.id))) appendMessage(p.new)}).subscribe()}
async function openChat(id){
 const {data}=await sb.from("profiles").select("id,full_name,avatar_url").eq("id",id).single();if(!data)return;activeUser=data;
 $("chatName").textContent=data.full_name||"User";$("chatAvatar").textContent=initials(data.full_name);$("chatView").classList.add("open");
 const {data:rows,error}=await sb.from("messages").select("*").or(`and(sender_id.eq.${me.id},receiver_id.eq.${id}),and(sender_id.eq.${id},receiver_id.eq.${me.id})`).order("created_at");
 if(error){$("messages").innerHTML="<div class='day'>Could not load messages</div>";return}
 $("messages").innerHTML="<div class='day'>Today</div>";(rows||[]).forEach(appendMessage);scrollBottom();
}
function appendMessage(m){
 if(document.querySelector(`[data-mid="${m.id}"]`))return;
 const d=document.createElement("div");d.dataset.mid=m.id;d.className="bubble "+(m.sender_id===me.id?"outgoing":"incoming");
 let body=escapeHtml(m.body||"");
 if(m.media_url){if(m.media_type?.startsWith("video"))body+=`<video controls src="${m.media_url}"></video>`;else body+=`<img src="${m.media_url}" alt="Shared image">`}
 d.innerHTML=body+`<span class="meta">${new Date(m.created_at).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</span>`;$("messages").appendChild(d);scrollBottom();
}
async function sendMessage(e){e.preventDefault();if(!activeUser)return;let body=$("messageInput").value.trim(),media_url=null,media_type=null;
 if(pendingFile){const ext=pendingFile.name.split(".").pop();const path=`${me.id}/${crypto.randomUUID()}.${ext}`;const up=await sb.storage.from("chat-media").upload(path,pendingFile,{upsert:false,contentType:pendingFile.type});if(up.error)return alert(up.error.message);const pub=sb.storage.from("chat-media").getPublicUrl(path);media_url=pub.data.publicUrl;media_type=pendingFile.type}
 if(!body&&!media_url)return;const {error}=await sb.from("messages").insert({sender_id:me.id,receiver_id:activeUser.id,body,media_url,media_type});if(error)alert(error.message);$("messageInput").value="";pendingFile=null;$("uploadPreview").textContent="";
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function scrollBottom(){$("messages").scrollTop=$("messages").scrollHeight}
$("loginBtn").onclick=login;$("signupBtn").onclick=signUp;$("logoutBtn").onclick=()=>sb.auth.signOut();
$("backBtn").onclick=()=>$("chatView").classList.remove("open");
$("userSearch").oninput=e=>loadUsers(e.target.value);
$("composer").onsubmit=sendMessage;
$("mediaInput").onchange=e=>{pendingFile=e.target.files[0]||null;$("uploadPreview").textContent=pendingFile?`Selected: ${pendingFile.name}`:""};
$("notifyBtn").onclick=async()=>{if(!("Notification"in window))return alert("Notifications are not supported here.");const p=await Notification.requestPermission();alert(p==="granted"?"Notifications enabled for this browser.":"Notification permission was not granted.")};
$("profileBtn").onclick=()=>alert(`Signed in as ${me?.email||""}`);
boot();